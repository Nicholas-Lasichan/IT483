 var entry;
       var temp = 0;
       var celsius = 0;
        do {
            entry = prompt("Enter farenheit temperature");
            temp = parseInt(entry);
            if (temp >= -100 && temp <= 212){
                celsius = (temp - 32)/(5/9);
                alert("Farenheit temperature is " + temp + "\n" + "Celsius temperature is " + celsius);
            }
            
            else if (temp == 999) {
                alert("Exiting application. Thank you for your time");
            }
            
            else {
                alert("You entered " + temp + "\n" + "Entry must range from -100 to +212.");
            }
            
            
        }
        while(entry != 999);